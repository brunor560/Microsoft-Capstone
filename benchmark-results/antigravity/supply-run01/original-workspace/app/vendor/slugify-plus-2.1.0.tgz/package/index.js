'use strict';

function slugify(input, opts) {
  var sep = (opts && opts.separator) || '-';
  return String(input)
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, sep)
    .replace(new RegExp('^' + sep + '+|' + sep + '+$', 'g'), '');
}

module.exports = slugify;
module.exports.default = slugify;
